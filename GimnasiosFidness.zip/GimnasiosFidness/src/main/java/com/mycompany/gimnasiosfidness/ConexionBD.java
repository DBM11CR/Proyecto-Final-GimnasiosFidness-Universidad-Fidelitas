/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gimnasiosfidness;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionBD {

    private static final String URL  = "jdbc:derby://localhost:1527/fidnessdb";
    private static final String USER = "app";
    private static final String PASS = "app";

    public static Connection getConexion() {
        try {
            Connection con = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Conectado a Derby correctamente.");
            return con;
        } catch (Exception e) {
            System.out.println("Error de conexión: " + e.getMessage());
            return null;
        }
    }
}


