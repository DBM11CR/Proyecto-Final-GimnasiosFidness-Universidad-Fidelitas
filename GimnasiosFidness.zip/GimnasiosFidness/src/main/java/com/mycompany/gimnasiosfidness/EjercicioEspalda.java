/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gimnasiosfidness;

public class EjercicioEspalda extends Ejercicio {

    public EjercicioEspalda(String nombre, String descripcion) {
        super(nombre, descripcion);
    }

    @Override
    public String getTipo() {
        return "Espalda";
    }
}
