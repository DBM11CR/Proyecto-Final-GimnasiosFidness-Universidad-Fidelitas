/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gimnasiosfidness;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

public class EjercicioDAO {

    public static List<Ejercicio> cargarEjercicios() {
        List<Ejercicio> lista = new ArrayList<>();

        String sql = "SELECT nombre, categoria, descripcion FROM ejercicios";

        try (Connection con = ConexionBD.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String cat = rs.getString("categoria");
                String desc = rs.getString("descripcion");

                Ejercicio e;
                switch (cat.toLowerCase()) {
                    case "pierna" -> e = new EjercicioPierna(nombre, desc);
                    case "espalda" -> e = new EjercicioEspalda(nombre, desc);
                    case "brazo" -> e = new EjercicioBrazo(nombre, desc);
                    default -> e = new EjercicioPierna(nombre, desc);
                }
                lista.add(e);
            }

        } catch (Exception e) {
            System.out.println("Error cargando ejercicios: " + e.getMessage());
        }

        return lista;
    }

    public static boolean insertarEjercicio(String nombre, String categoria, String descripcion) {
        String sql = "INSERT INTO ejercicios (nombre, categoria, descripcion) VALUES (?, ?, ?)";

        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, nombre);
            ps.setString(2, categoria);
            ps.setString(3, descripcion);
            ps.executeUpdate();
            return true;

        } catch (Exception e) {
            System.out.println("Error insertando ejercicio: " + e.getMessage());
            return false;
        }
    }
}


