/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gimnasiosfidness;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class Rutina {

    private String usuario;
    private List<Ejercicio> ejercicios = new ArrayList<>();

    public Rutina(String usuario) {
        this.usuario = usuario;
    }

    public void agregar(Ejercicio e) {
        ejercicios.add(e);
    }

    public String getTexto() {
        StringBuilder sb = new StringBuilder();
        sb.append("Rutina de: ").append(usuario).append("\n\n");
        for (Ejercicio e : ejercicios) {
            sb.append(e.getDetalle()).append("\n");
        }
        return sb.toString();
    }

    public void exportar() throws Exception {
        try (FileWriter fw = new FileWriter("rutina_" + usuario + ".txt")) {
            fw.write(getTexto());
        }
    }
}

