/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gimnasiosfidness;

public class EjercicioPierna extends Ejercicio {

    public EjercicioPierna(String nombre, String descripcion) {
        super(nombre, descripcion);
    }

    @Override
    public String getTipo() {
        return "Pierna";
    }
}


