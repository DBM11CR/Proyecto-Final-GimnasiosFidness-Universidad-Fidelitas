/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gimnasiosfidness;

import javax.swing.JOptionPane;
import java.util.List;

public class GimnasiosFidness {

    public static void main(String[] args) {

        String usuario = null;
        String pass = null;
        boolean logueado = false;

        String[] opcionesInicio = {"Ingresar", "Crear usuario", "Salir"};
        int opInicio = JOptionPane.showOptionDialog(
                null,
                "Seleccione una opción",
                "Gimnasios Fidness",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                opcionesInicio,
                opcionesInicio[0]
        );

        if (opInicio == 2 || opInicio == -1) return;

        usuario = JOptionPane.showInputDialog("Usuario:");
        pass = JOptionPane.showInputDialog("Contraseña:");

        if (usuario == null || pass == null || usuario.isBlank() || pass.isBlank()) return;

        if (opInicio == 1) { // Crear usuario
            if (UsuarioDAO.registrar(usuario, pass)) {
                JOptionPane.showMessageDialog(null, "Usuario creado correctamente.\nAhora ingresará con ese usuario.");
                if (!UsuarioDAO.login(usuario, pass)) {
                    JOptionPane.showMessageDialog(null, "Error al iniciar sesión después de crear el usuario.");
                    return;
                }
                logueado = true;
            } else {
                JOptionPane.showMessageDialog(null, "Error creando usuario.");
                return;
            }
        } else { // Ingresar
            if (!UsuarioDAO.login(usuario, pass)) {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos");
                return;
            }
            logueado = true;
        }

        if (!logueado) return;

        JOptionPane.showMessageDialog(null, "Bienvenido " + usuario);

        boolean seguirMenu = true;

        while (seguirMenu) {
            String[] opciones = {
                    "Ingresar ejercicio",
                    "Consultar ejercicios",
                    "Crear rutina y exportar",
                    "Salir"
            };

            int op = JOptionPane.showOptionDialog(
                    null,
                    "Seleccione una opción",
                    "Menú principal",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]
            );

            if (op == 3 || op == -1) {
                seguirMenu = false;
            } else if (op == 0) {
                // Ingresar ejercicio
                String nombre = JOptionPane.showInputDialog("Nombre del ejercicio:");
                if (nombre == null || nombre.isBlank()) continue;

                String categoria = JOptionPane.showInputDialog("Categoría (pierna, espalda, brazo):");
                if (categoria == null || categoria.isBlank()) continue;

                String descripcion = JOptionPane.showInputDialog("Descripción / cómo se ejecuta:");
                if (descripcion == null || descripcion.isBlank()) continue;

                if (EjercicioDAO.insertarEjercicio(nombre, categoria, descripcion)) {
                    JOptionPane.showMessageDialog(null, "Ejercicio guardado en la base de datos.");
                } else {
                    JOptionPane.showMessageDialog(null, "Error guardando el ejercicio.");
                }

            } else if (op == 1) {
                // Consultar ejercicios
                List<Ejercicio> ejercicios = EjercicioDAO.cargarEjercicios();
                if (ejercicios.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No hay ejercicios en la base de datos.");
                    continue;
                }

                StringBuilder sb = new StringBuilder("Ejercicios disponibles:\n\n");
                for (int i = 0; i < ejercicios.size(); i++) {
                    sb.append(i).append(") ").append(ejercicios.get(i).getDetalle()).append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString());

            } else if (op == 2) {
                // Crear rutina y exportar
                List<Ejercicio> ejercicios = EjercicioDAO.cargarEjercicios();
                if (ejercicios.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No hay ejercicios en la base de datos.");
                    continue;
                }

                StringBuilder sb = new StringBuilder("Ejercicios disponibles:\n\n");
                for (int i = 0; i < ejercicios.size(); i++) {
                    sb.append(i).append(") ").append(ejercicios.get(i).getDetalle()).append("\n");
                }
                JOptionPane.showMessageDialog(null, sb.toString());

                Rutina rutina = new Rutina(usuario);
                boolean agregando = true;

                while (agregando) {
                    String idxStr = JOptionPane.showInputDialog("Digite el número del ejercicio para agregar (o vacío para terminar):");
                    if (idxStr == null || idxStr.isBlank()) break;

                    try {
                        int idx = Integer.parseInt(idxStr);
                        if (idx < 0 || idx >= ejercicios.size()) {
                            JOptionPane.showMessageDialog(null, "Índice inválido.");
                        } else {
                            rutina.agregar(ejercicios.get(idx));
                            JOptionPane.showMessageDialog(null, "Ejercicio agregado a la rutina.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Debe digitar un número.");
                    }

                    int op2 = JOptionPane.showConfirmDialog(null, "¿Agregar otro ejercicio?");
                    if (op2 != JOptionPane.YES_OPTION) agregando = false;
                }

                try {
                    rutina.exportar();
                    JOptionPane.showMessageDialog(null, "Rutina exportada correctamente.");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Error al exportar la rutina.");
                }
            }
        }
    }
}

