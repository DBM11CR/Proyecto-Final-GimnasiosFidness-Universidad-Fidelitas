/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gimnasiosfidness;

public abstract class Ejercicio {

    protected String nombre;
    protected String descripcion;

    public Ejercicio(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getNombre() { return nombre; }

    public abstract String getTipo();

    public String getDetalle() {
        return getTipo() + " - " + nombre + ": " + descripcion;
    }
}


